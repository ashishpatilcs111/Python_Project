// Load classification data from the JSON file
const classification = require('./keyword_base_classification.json').Resolution_Type;
const parameters_keywords = require('./keyword_base_classification.json').Parameters_KeyWords;
const search_patterns = require('./keyword_base_classification.json').search_patterns;
const common_search_patterns = search_patterns["common"];

// Sample email body for extraction
const emailBody = `
Please send me the profit and loss statement and trade report for the period of April 2024 to March 2025. 
My customer ID is 987654321 and account number is 1122334455. Also, trading a/c no is 99887766. 
My email is sampleuser@example.com and mobile number is 9876543210.
`;

// Normalize the email body text to lowercase for case-insensitive matching
const normalizedText = emailBody.toLowerCase();

/**
 * Helper function to extract a value from the text using a set of regex patterns.
 * It prioritizes specific patterns for a given parameter and falls back to common patterns.
 *
 * @param {string} text The text to search within (e.g., email body).
 * @param {string} keyword The keyword associated with the parameter (e.g., "customer id").
 * @param {string[]} params_patterns An array of specific regex pattern strings for the parameter.
 * @returns {string|null} The extracted value or null if no match is found.
 */
function extractValue(text, keyword, params_patterns) {
    let patternsToTry = [];

    // Prioritize specific patterns for the parameter if they exist.
    if (params_patterns && params_patterns.length > 0) {
        // Create RegExp objects. The 'i' flag makes it case-insensitive.
        // The 'g' flag is intentionally omitted here because RegExp.prototype.exec()
        // is used below, which processes one match at a time, and we're looking
        // for the first successful pattern match among the provided patterns.
        patternsToTry = params_patterns.map(p => new RegExp(p, 'i'));
    } else {
        // If no specific patterns are defined for the parameter,
        // fall back to common dynamic patterns.
        // These dynamic regexes are created using the 'getDynamicRegex' helper
        // and should ideally have a single capturing group for the value.
        patternsToTry = common_search_patterns.map(p => getDynamicRegex(p, keyword));
    }

    // Iterate through the generated patterns to find a match.
    for (let regex of patternsToTry) {
        // The exec() method is used for robust extraction, especially with capturing groups.
        // It returns an array of information about the first match, or null if no match is found.
        const match = regex.exec(text);

        // If a match is found using the current regex pattern
        if (match) {
            // If there are capturing groups (match.length > 1 means match[0] plus at least one capturing group),
            // return the content of the last capturing group.
            // This assumes the desired value is consistently located in the last capturing group
            // of the regex patterns defined in the JSON.
            // If there are no capturing groups (only match[0] exists), return the full matched string.
            return match.length > 1 ? match[match.length - 1] : match[0];
        }
    }

    // If no match is found after trying all patterns, return null.
    return null;
}

/**
 * Helper function to dynamically create a regex pattern string by embedding a keyword.
 * This is used for common patterns where the keyword is a placeholder.
 *
 * @param {string} pattern The base regex pattern string containing a '${keyword}' placeholder.
 * @param {string} keyword The keyword to embed into the pattern.
 * @returns {RegExp} A new RegExp object with the keyword embedded.
 */
function getDynamicRegex(pattern, keyword) {
    // Escape any special regex characters in the keyword to ensure it's treated literally
    const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // Replace the '${keyword}' placeholder in the pattern string with the escaped keyword
    const patternStr = pattern.replace('${keyword}', escaped);
    // Return a new RegExp object for the dynamic pattern, case-insensitive ('i' flag).
    // The 'g' flag is omitted here for consistency with exec() usage in extractValue.
    return new RegExp(patternStr, 'i');
}

/**
 * Main extraction logic function.
 * This function processes the email body to identify categories and extract relevant parameters.
 *
 * @param {string} emailBody The full text of the email body.
 * @returns {Array<Object>} An array of objects, each representing a matched category
 * with its extracted parameters.
 */
function extractFromEmail(emailBody) {
    const matches = []; // Initialize an array to store all identified categories and their extracted parameters

    // Iterate through each defined resolution category (e.g., Profit_N_Loss_Statement, Trade_Reports)
    // 'classification' is loaded from 'keyword_base_classification.json'.
    for (const [category, details] of Object.entries(classification)) {
        // Convert the email body to lowercase for case-insensitive keyword matching for category identification.
        const lowercasedEmailBody = emailBody.toLowerCase();

        // Check if any of the category's 'request_keywords' are present in the email body.
        // This determines if the current email is relevant to this category.
        const matchedRequestKeyword = details.request_keywords.find(kw => lowercasedEmailBody.includes(kw.toLowerCase()));

        // If a matching request keyword is found for the current category
        if (matchedRequestKeyword) {
            const paramResults = {}; // Initialize an object to store extracted parameter values for this category

            // Iterate through each parameter defined for the current category (e.g., "customer_id", "account_number").
            // 'details.parameters' is an array of parameter names.
            for (const paramName of details.parameters) {
                // Get the list of keywords associated with this specific parameter (e.g., ["customer id", "cust id"]).
                const param_keywords = parameters_keywords[paramName];
                // Get the specific regex patterns defined for this parameter, if any.
                const params_patterns = search_patterns[paramName];

                let foundKeyword = null;
                // If keywords are defined for the parameter, check if any of them exist in the normalized email text.
                if (param_keywords) {
                    foundKeyword = param_keywords.find(k => normalizedText.includes(k.toLowerCase()));
                }

                // If a keyword for the parameter is found in the email, attempt to extract its value.
                if (foundKeyword) {
                    // Call the helper function to extract the value using the email body, the found keyword,
                    // and the parameter's specific regex patterns.
                    const value = extractValue(emailBody, foundKeyword, params_patterns);
                    // Store the extracted value. If no value is found, store null.
                    paramResults[paramName] = value || null;
                } else {
                    // If no keyword for the parameter is found, no value can be extracted for it.
                    paramResults[paramName] = null;
                }
            }

            // Add the results for this category (including its matched keyword and extracted parameters)
            // to the main 'matches' array.
            matches.push({
                category,
                matched_keyword: matchedRequestKeyword,
                parameters: paramResults
            });
        }
    }

    return matches; // Return the complete array of extracted matches.
}

// Run the main extraction logic with the sample email body and print the results to the console.
// JSON.stringify with null and 2 for pretty-printing the output.
const result = extractFromEmail(emailBody);
console.log(JSON.stringify(result, null, 2));
